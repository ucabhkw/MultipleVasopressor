--Destination table: mimiciii-250307:view_multi_mimiciv.multiple_vaso_v9_step0
--This is to clean up data by connecting a continuous vasopressor.

--Standard SQL
CREATE TEMP FUNCTION EXCLEAST(x ARRAY<TIMESTAMP>) AS
((SELECT MIN(y) FROM UNNEST(x) AS y WHERE y IS NOT NULL));

WITH icustays AS
(
 #This is in the multiple_vaso_v9 as well. It's to minimized the icu records before we go for the next steps, and also check whether we are missing any record error in terms of death. Luckily, it seems deathtime is well written by subject (patient) level. 
 select * 
 FROM (select *,
   RANK() OVER (PARTITION BY subject_id ORDER BY deathtime DESC) AS death_row_num
   FROM (
     select distinct ie.subject_id, ie.hadm_id, ie.stay_id AS icustay_id, 
      TIMESTAMP(ie.icu_intime) AS intime, TIMESTAMP(ie.icu_outtime) AS outtime, ie.gender,
      ie.admission_age AS age, ie.ethnicity, 
      CASE WHEN ie.ethnicity = 'WHITE' THEN 1 ELSE 0 END ethnicity_cat,
      ie.los_icu, ie.los_hospital, 
      CASE WHEN ie2.deathtime is not null THEN TIMESTAMP(ie2.deathtime)
           WHEN ie.hospital_expire_flag = 1 
                and ie.dod is not null and ie2.deathtime is null 
                and ie.dod = EXTRACT(DATE FROM TIMESTAMP(ie.icu_outtime)) 
                and ie.dod = EXTRACT(DATE FROM TIMESTAMP(ie.dischtime)) 
                THEN EXCLEAST([TIMESTAMP(ie.icu_outtime), TIMESTAMP(ie.dischtime)])
           WHEN ie.hospital_expire_flag = 1 
                and ie.dod is not null and ie2.deathtime is null 
                and ie.dod = EXTRACT(DATE FROM TIMESTAMP(ie.icu_outtime)) 
                and ie.dod != EXTRACT(DATE FROM TIMESTAMP(ie.dischtime)) 
                THEN TIMESTAMP(ie.icu_outtime)
           WHEN ie.hospital_expire_flag = 1 
                and ie.dod is not null and ie2.deathtime is null 
                and ie.dod != EXTRACT(DATE FROM TIMESTAMP(ie.icu_outtime)) 
                and ie.dod = EXTRACT(DATE FROM TIMESTAMP(ie.dischtime)) 
                THEN TIMESTAMP(ie.dischtime)
           ELSE TIMESTAMP(ie.dod)
           END AS deathtime
    FROM `physionet-data.mimic_derived.icustay_detail` AS ie
    LEFT JOIN `physionet-data.mimic_core.admissions` AS ie2
    ON ie.subject_id = ie2.subject_id and ie.hadm_id = ie2.hadm_id
    )
  ) WHERE death_row_num = 1
),  
# This is to extract vasopressor records from inputevents table (MetaVision).
input_mv_tmp AS
(  select distinct ie.subject_id, ie.hadm_id, ie.icustay_id, itemid, amount, rate,
  TIMESTAMP(mv.starttime) AS startdate, TIMESTAMP(mv.endtime) AS enddate
  FROM icustays AS ie
  INNER JOIN `physionet-data.mimic_icu.inputevents` mv
  on ie.subject_id = mv.subject_id AND ie.hadm_id = mv.hadm_id AND ie.icustay_id = mv.stay_id
  where mv.statusdescription != 'Rewritten'
  and floor(TIMESTAMP_DIFF(TIMESTAMP(mv.endtime), TIMESTAMP(mv.starttime), SECOND))> 0  
  and mv.amount is not null and mv.amount > 0.0
  and mv.itemid in (229764, 229709, 221662, 221289, 221749, 222315, 221906)
),
# This is to see whether we should combine the current record with next records (tmp0 ~).
tmp0 AS
(
  SELECT subject_id, hadm_id, icustay_id, startdate, enddate, itemid, amount, rate
      , LAG(startdate, 1) OVER (PARTITION BY icustay_id, itemid ORDER BY startdate) AS startdate_lag
      , LEAD(startdate, 1) OVER w AS startdate_lead
      , LAG(enddate, 1) OVER (PARTITION BY icustay_id, itemid ORDER BY enddate) AS enddate_lag
      , LEAD(enddate, 1) OVER (PARTITION BY icustay_id, itemid ORDER BY enddate) AS enddate_lead
  FROM input_mv_tmp
  WINDOW w AS (PARTITION BY icustay_id, itemid ORDER BY startdate)
),
tmp1 AS
(
    SELECT subject_id, hadm_id, icustay_id, itemid
        , startdate_lag
        , startdate
        , startdate_lead
        , enddate_lag
        , enddate
        , enddate_lead
        , amount, rate
        -- calculate the time since the last event
        , DATETIME_DIFF(startdate, startdate_lag, MINUTE)/60 as medduration
        -- now we determine if the current vasopressor status is "new", or continuing the previous
        , CASE
            -- a 1 second gap always initiates a new event
            WHEN startdate_lag is null THEN 1
            WHEN startdate != enddate_lag THEN 1 
          ELSE 0
          END AS new_status
    FROM tmp0
)
, tmp2 as
(
    SELECT tmp1.*
    -- create a cumulative sum of the instances of new medication
    -- this results in a monotonic integer assigned to each instance of medication
    , SUM(new_status) OVER (PARTITION BY icustay_id, itemid ORDER BY startdate) AS med_num
    FROM tmp1
)
-- create the durations for each vasopressor instance
SELECT subject_id, hadm_id, icustay_id, itemid
  , MIN(startdate) AS startdate
  -- for the end time of the vasopressor event, the time of the *next* setting
  , MAX(
        CASE
            WHEN enddate_lead IS NULL 
                OR enddate != startdate_lead 
                THEN enddate 
        ELSE enddate_lead 
        END
   ) AS enddate
   , SUM(amount) AS amount
   , SUM(rate) AS rate
FROM tmp2
GROUP BY subject_id, hadm_id, icustay_id, itemid, med_num
order by subject_id, hadm_id, itemid, startdate